//
//  Growlytics.h
//  Growlytics
//
//  Created by Pradeep Singh on 04/03/20.
//  Copyright © 2020 Growlytics Technologies Pvt Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Growlytics.
FOUNDATION_EXPORT double GrowlyticsVersionNumber;

//! Project version string for Growlytics.
FOUNDATION_EXPORT const unsigned char GrowlyticsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Growlytics/PublicHeader.h>


