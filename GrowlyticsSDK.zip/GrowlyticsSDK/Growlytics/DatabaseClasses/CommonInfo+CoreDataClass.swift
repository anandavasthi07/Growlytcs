//
//  CommonInfo+CoreDataClass.swift
//  Growlytics
//
//  Created by Pradeep Singh on 07/03/20.
//  Copyright © 2020 Growlytics Technologies Pvt Ltd. All rights reserved.
//
//

import Foundation
import CoreData

@objc(CommonInfo)
class CommonInfo: NSManagedObject {

}
