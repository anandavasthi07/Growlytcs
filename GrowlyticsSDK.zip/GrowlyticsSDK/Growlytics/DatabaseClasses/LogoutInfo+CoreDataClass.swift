//
//  LogoutInfo+CoreDataClass.swift
//  Growlytics
//
//  Created by Ankit Singh  on 17/03/23.
//  Copyright © 2023 Growlytics Technologies Pvt Ltd. All rights reserved.
//
//

import Foundation
import CoreData

@objc(LogoutInfo)
public class LogoutInfo: NSManagedObject {

}
