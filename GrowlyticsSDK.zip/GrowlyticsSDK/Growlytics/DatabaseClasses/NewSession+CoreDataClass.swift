//
//  NewSession+CoreDataClass.swift
//  Growlytics
//
//  Created by Ankit Singh  on 13/03/23.
//  Copyright © 2023 Growlytics Technologies Pvt Ltd. All rights reserved.
//
//

import Foundation
import CoreData

@objc(NewSession)
public class NewSession: NSManagedObject {

}
